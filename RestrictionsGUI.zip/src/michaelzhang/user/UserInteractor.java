package michaelzhang.user;
/*
 * handles the interactive parts of the GUI,
 * such as bringing up the window for selecting the file location,
 * bringing up the selectors for the table to insert into, etc.
 */
public class UserInteractor {

}
